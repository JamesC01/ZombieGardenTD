09/02/2024

I've become much more open minded when listening to guys like Casey Muratori, and I feel like I've learned a lot.
The goal of this project is to apply the idea of writing code as simply as possible, without too much planning,
and no premature abstraction. Another goal is to also just enjoy programming. Enjoy lower level C programming.
Also partly to see if I even do enjoy it. I spent around 1 hour today workong on this project.


10/02/2024

I've spent 3 hours (2 hours today) on this project so far (including doing the sprites) and I'm really enjoying it.
It feels very natural, and I'm not doing too much planning, it's just organically growing. I think planning should
be a balance. Planning can be very difficult when there are lots of different things interacting. It's too much to
keep in your head, or even written down, sometimes, so this gung-ho style of programming feels very nice. I like the idea of
just loosely planning something, or thinking about a simple implementation of it, and then just doing it. It feels
right.

I'm definitely doing a bit of planning, but it's mostly in my head. I'm just thinking of the simplest ways of doing
things, and then thinking a *little* bit further about how the thing I'm implementing might interact with the other
things in my game. The mentality I'm going for is one where I plan simple things (either in my head, or write them
down), and just implement them. If they need changing later, then so be it. The truth is, even if I spent an hour
planning, there's still a good chance I'd overlook something, so I think it's good to just get it out of the way
and implement it in a working, but not very abstracted way, and then if I find myself repeating similar code, then
I can think about how to abstract/compress it.

The planning I've been thinking about is stuff like "how will the projectiles hit the zombies?" and "how will the
zombies be able to eat the plants?" When thinking about these types of problems, I find my brains tries to think
of ways of implementing it, which is great. I think the problem arises from when spend too much time planning, and
try too hard to plan ahead for future features, when you aren't even sure how to implement them. Actually planning
the implementation isn't too bad, but it's when you abstract it before you even need to. Regardless, I still really
like this feeling of not obsessively planning. It feels fun. It's similar to what Casey Muratori describes as
"exploration-based architecture", where you aren't 100% how to solve the problem, so you're just exploring around,
rather than planning heavily, since you aren't sure what you're in for.


11/02/2024

Today I spent 2 hours and 3 minutes getting suns working in the game, making a shovel sprite, and making the seedpackets
and shovel have a shadow behind them when they're being dragged. Implementing stuff from scratch like this seems to take
quite a while, but I'm enjoying myself, and I'd imagine it gets faster with time. I suppose you get the added benefit of
knowing how pretty much all of your game logic works, whereas in an engine, the engine would handle a lot of it for you,
which can get in the way of things, sometimes. I think both are good. When I want to make something more ambitious, with
lots of features like animations, physics, UI, etc., then I'd probably go with Godot. But if I want to enjoy some programming,
and also just have some fun, then doing stuff from scratch is great, and very worthwhile, because it just gives you more
in-depth problems-solving experience.

So after 5 hours working on this game, I've gotten a peashooter plant and a garden grid where you can place them. I've got
suns that act as a currancy. I've got a shovel which allows you to dig up plants, and that's about it. Of course, a lot actually
went into it. I had to do 99% of the logic myself. There's a couple utily functions for doing simple collision checks that are
built into raylib, but I could do those trivially.

Maybe at some point the novetly of writing this (mostly) from scratch in C will run out, or maybe this will be start of
many more from-scratch projects. I think the areas that I will get bored of are repetetive ones, where I find myself
writing the same code multiple times for different projects. If I get to that point, instead of getting bored, maybe just
copy-paste, or try to create a simple library that I can bring into future projects.

Then again, I have written multiple projects without an engine, and I've enjoyed pretty much all of them. Although it isn't
fun to write the same code over and over without improvements, so like I said, make a library out of it. Doesn't have to
be amazingly designed.

I think the projects that favour being made from scratch are tile/grid based things. A voxel engine, a roguelike, a game like
terraria. These are all things I've had a go at making, and they're all fairly nice to implement when doing it from scratch.
Engines kind of complicate games like this, where you might need procedural generation, and need a lot of control over specific
things.

When I tried to make a zelda-like RPG, I had quite a hard time. But with that project, it was very object-oriented and I think
I overcomplicated things. If I redid that project, or made a slightly similar one, but with less complex features, closer to Zelda
1, maybe it wouldn't be too hard, to at least get most of the mechanics working. Could be a good challenge, but I'm not sure if
I want to spent like a month on something just for a challenge. The C++ roguelike I made, and the C# monogame RPG I made both took
about a month, and they were both very minimal and kind of boring. If I'm going to put time into a complex project from-scratch like
that, I'd want to do it differently, and kind of have more fun with it, and create something actually interesting. You only have so
much time in your life, so I'd rather spend it making something cool, rather than spending a month on something that I did purely
as a coding exercise. You can enjoy coding, and get better at it by working on creative projects. Ironically, you probably would actually
improve more at something you enjoy making, because you're more engaged in it. So while it seems like a good idea to do something as
a "coding exercise", it's probably just better to have fun and explore (most of the time, at least.)

I think from-scratch development *can* be fast, once you're good at it, but I'll have to wait and see. Regardless of if it takes a lot
more time or not, it's still enjoyable, and valuable.

The next time I work on this project, I would like to get some sound effects working. That would really bring it to life.
I think the next plant I'll work on is the sunflower. Once that's implemented, the zombies should come next!


12/02/2024

Took 1 hour and 20 minutes this session! I did a decent bit. I implemented cooldowns for the seed packets, I refactored a decent bit of
stuff, pulled stuff out into seperate functions when the function became hard to read, replaced a bunch of hardcoded values with constants,
I implemented a sunflower (not done the sprite yet), and I fixed a bug where the mouse being clicked would highlight the grid even when
you weren't dragging anything. There might be more things, but that's the bulk of it. It's coming along quite nicely. Implenting the sunflowers
didn't take very long, at most about 30 minutes, but that includes a bit of refactoring. I used a lookup table for finding the plant cooldowns,
because putting a cooldownMax variable on every plant didn't feel right, for some reason. Having to keep those values consistent when spawning
the plant just seems like an extra step, so I put all of the cooldown values in an array, and used the PlantType enums to index into it. I got
this idea from seeing some code Casey Muratori wrote, where he used a lookup table for something. I'm not sure if it's the right thing to do
in this case, but it felt right.


13/02/2024

Spent 1 hour 32 minutes this session. I made the sunflower sprite, made lots of small tweaks, and also implemented zombies (currently using a
ripped plants vs zombies sprite). They spawn from the right side of the screen, and can be damaged from projectiles, and when they run into
a plant, they stop moving and start damaging it. It all works so far! Still no sound effects yet, but I had a good time implementing zombies.
